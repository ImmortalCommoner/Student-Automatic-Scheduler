import { Upload, Calendar, Settings, LogOut, FileText } from 'lucide-react';
import type { UserData, ScheduleData } from '@/app/App';

interface HomeScreenProps {
  userData: UserData;
  scheduleData: ScheduleData | null;
  onUpload: () => void;
  onViewSchedule: () => void;
  onSettings: () => void;
  onLogout: () => void;
  showUniform: boolean;
}

export function HomeScreen({ 
  userData, 
  scheduleData, 
  onUpload, 
  onViewSchedule, 
  onSettings, 
  onLogout,
  showUniform 
}: HomeScreenProps) {
  const currentDate = new Date();
  const dayName = currentDate.toLocaleDateString('en-US', { weekday: 'long' });
  const dateString = currentDate.toLocaleDateString('en-US', { 
    month: 'long', 
    day: 'numeric',
    year: 'numeric'
  });

  // Get today's classes
  const todayClasses = scheduleData?.classes.filter(c => c.day === dayName) || [];
  const todayUniform = todayClasses.find(c => c.uniform)?.uniform;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl text-gray-900">Welcome back,</h2>
            <p className="text-lg text-primary">{userData.name}</p>
          </div>
          <button 
            onClick={onSettings}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Settings className="w-6 h-6 text-gray-600" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Current Week */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-5 h-5 text-primary" />
            <p className="text-sm text-gray-600">Current Date</p>
          </div>
          <p className="text-lg text-gray-900">{dayName}</p>
          <p className="text-sm text-gray-500">{dateString}</p>
        </div>

        {/* Uniform Reminder Card */}
        {showUniform && todayUniform && (
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-2xl p-5 border border-blue-200">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-base text-gray-900 mb-1">Uniform Reminder</h3>
                <p className="text-sm text-gray-700">
                  Today's uniform: <span className="font-medium">{todayUniform}</span>
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Weekly Schedule Preview */}
        {scheduleData ? (
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base text-gray-900">This Week's Schedule</h3>
              <button
                onClick={onViewSchedule}
                className="text-sm text-primary hover:underline"
              >
                View All
              </button>
            </div>
            
            {todayClasses.length > 0 ? (
              <div className="space-y-3">
                {todayClasses.map((classItem) => (
                  <div 
                    key={classItem.id}
                    className={`p-4 rounded-xl border ${
                      classItem.type === 'face-to-face' 
                        ? 'bg-blue-50 border-blue-200' 
                        : 'bg-red-50 border-red-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-sm text-gray-900 mb-1">{classItem.subjectName}</p>
                        <p className="text-xs text-gray-600">{classItem.subjectCode}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-600">{classItem.startTime} - {classItem.endTime}</p>
                        <p className={`text-xs mt-1 ${
                          classItem.type === 'face-to-face' ? 'text-blue-700' : 'text-red-700'
                        }`}>
                          {classItem.type === 'face-to-face' ? 'Face-to-Face' : 'Virtual'}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">No classes today</p>
            )}
          </div>
        ) : (
          <div className="bg-gray-50 rounded-2xl p-8 text-center border border-gray-200 border-dashed">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-200 flex items-center justify-center">
              <Calendar className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-sm text-gray-600 mb-1">No schedule uploaded yet</p>
            <p className="text-xs text-gray-500">Upload your schedule to get started</p>
          </div>
        )}

        {/* Upload Button */}
        <button
          onClick={onUpload}
          className="w-full py-4 bg-primary text-primary-foreground rounded-xl hover:opacity-90 transition-opacity shadow-md flex items-center justify-center gap-2"
        >
          <Upload className="w-5 h-5" />
          <span>{scheduleData ? 'Update Schedule' : 'Upload Schedule'}</span>
        </button>

        {/* Logout Button */}
        <button
          onClick={onLogout}
          className="w-full py-3 bg-white text-gray-700 rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
}
