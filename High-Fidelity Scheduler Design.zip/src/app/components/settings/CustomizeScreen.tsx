import { ArrowLeft, Moon, Sun, Calendar, Eye, EyeOff, Type } from 'lucide-react';

interface CustomizeScreenProps {
  isDarkMode: boolean;
  viewMode: 'week' | 'day';
  showUniform: boolean;
  fontSize: 'small' | 'medium' | 'large';
  onDarkModeToggle: () => void;
  onViewModeChange: (mode: 'week' | 'day') => void;
  onShowUniformToggle: () => void;
  onFontSizeChange: (size: 'small' | 'medium' | 'large') => void;
  onBack: () => void;
}

export function CustomizeScreen({
  isDarkMode,
  viewMode,
  showUniform,
  fontSize,
  onDarkModeToggle,
  onViewModeChange,
  onShowUniformToggle,
  onFontSizeChange,
  onBack
}: CustomizeScreenProps) {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Header */}
      <div className="border-b border-gray-100 dark:border-gray-800 px-6 py-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700 dark:text-gray-300" />
          </button>
          <h1 className="text-xl text-gray-900 dark:text-white">Customize View</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Dark Mode */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                {isDarkMode ? (
                  <Moon className="w-5 h-5 text-primary" />
                ) : (
                  <Sun className="w-5 h-5 text-primary" />
                )}
              </div>
              <div>
                <p className="text-sm text-gray-900 dark:text-white font-medium">Dark Mode</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">Switch to dark theme</p>
              </div>
            </div>
            <button
              onClick={onDarkModeToggle}
              className={`relative w-14 h-8 rounded-full transition-colors ${
                isDarkMode ? 'bg-primary' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform ${
                  isDarkMode ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* View Mode */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Calendar className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900 dark:text-white font-medium">Schedule View</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Choose your preferred view</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onViewModeChange('week')}
              className={`py-3 px-4 rounded-xl text-sm transition-all ${
                viewMode === 'week'
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600'
              }`}
            >
              Week View
            </button>
            <button
              onClick={() => onViewModeChange('day')}
              className={`py-3 px-4 rounded-xl text-sm transition-all ${
                viewMode === 'day'
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600'
              }`}
            >
              Day View
            </button>
          </div>
        </div>

        {/* Show Uniform */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                {showUniform ? (
                  <Eye className="w-5 h-5 text-primary" />
                ) : (
                  <EyeOff className="w-5 h-5 text-primary" />
                )}
              </div>
              <div>
                <p className="text-sm text-gray-900 dark:text-white font-medium">Uniform Reminders</p>
                <p className="text-xs text-gray-600 dark:text-gray-400">Show uniform information</p>
              </div>
            </div>
            <button
              onClick={onShowUniformToggle}
              className={`relative w-14 h-8 rounded-full transition-colors ${
                showUniform ? 'bg-primary' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform ${
                  showUniform ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Font Size */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Type className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900 dark:text-white font-medium">Font Size</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Adjust text size</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => onFontSizeChange('small')}
              className={`py-3 px-4 rounded-xl text-xs transition-all ${
                fontSize === 'small'
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600'
              }`}
            >
              Small
            </button>
            <button
              onClick={() => onFontSizeChange('medium')}
              className={`py-3 px-4 rounded-xl text-sm transition-all ${
                fontSize === 'medium'
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600'
              }`}
            >
              Medium
            </button>
            <button
              onClick={() => onFontSizeChange('large')}
              className={`py-3 px-4 rounded-xl text-base transition-all ${
                fontSize === 'large'
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600'
              }`}
            >
              Large
            </button>
          </div>
        </div>

        {/* Info Section */}
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-5">
          <p className="text-sm text-gray-700 dark:text-gray-300">
            <span className="font-medium">Note:</span> These settings only affect the visual presentation. 
            Your schedule data remains unchanged.
          </p>
        </div>

        {/* Preview Text */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-5">
          <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">Preview:</p>
          <p className="text-gray-900 dark:text-white">
            This is how your schedule text will appear
          </p>
        </div>
      </div>
    </div>
  );
}
