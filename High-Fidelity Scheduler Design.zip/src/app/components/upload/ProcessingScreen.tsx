import { Loader2, FileSearch, Calendar, CheckCircle } from 'lucide-react';

export function ProcessingScreen() {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-6">
      <div className="max-w-sm w-full space-y-8">
        {/* Loading Animation */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
              <Loader2 className="w-12 h-12 text-primary animate-spin" />
            </div>
          </div>
        </div>

        {/* Status Text */}
        <div className="text-center space-y-2">
          <h2 className="text-xl text-gray-900">Processing Your Schedule</h2>
          <p className="text-sm text-gray-500">
            This will only take a moment...
          </p>
        </div>

        {/* Progress Steps */}
        <div className="space-y-4">
          <div className="flex items-start gap-3 p-4 bg-green-50 rounded-xl border border-green-200">
            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900 font-medium">Reading schedule...</p>
              <p className="text-xs text-gray-600 mt-0.5">Completed</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-xl border border-blue-200">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
              <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-900 font-medium">Organizing by day and time...</p>
              <p className="text-xs text-gray-600 mt-0.5">In progress</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
              <Calendar className="w-5 h-5 text-gray-400" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-600">Creating your weekly view...</p>
              <p className="text-xs text-gray-500 mt-0.5">Pending</p>
            </div>
          </div>
        </div>

        {/* Info Text */}
        <div className="text-center">
          <p className="text-xs text-gray-500">
            Please don't close this screen
          </p>
        </div>
      </div>
    </div>
  );
}
