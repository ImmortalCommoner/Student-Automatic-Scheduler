import { useState, useRef } from 'react';
import { ArrowLeft, Upload, FileImage, FileText, X, CheckCircle } from 'lucide-react';

interface UploadScreenProps {
  onUpload: (file: File) => void;
  onBack: () => void;
}

export function UploadScreen({ onUpload, onBack }: UploadScreenProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (validTypes.includes(file.type)) {
      setSelectedFile(file);
    } else {
      alert('Please upload a JPG, PNG, or PDF file');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleSubmit = () => {
    if (selectedFile) {
      onUpload(selectedFile);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b border-gray-100 px-6 py-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 -ml-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-xl text-gray-900">Upload Your Class Schedule</h1>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
          <p className="text-sm text-gray-700 mb-2">
            <span className="font-medium">Instructions:</span>
          </p>
          <p className="text-sm text-gray-600 leading-relaxed">
            Upload the schedule provided by your school. The app will organize it automatically. 
            We support image files (JPG, PNG) and PDF documents.
          </p>
        </div>

        {/* Upload Area */}
        <div
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          className={`border-2 border-dashed rounded-2xl p-8 transition-all ${
            isDragging 
              ? 'border-primary bg-primary/5 scale-[0.98]' 
              : 'border-gray-300 hover:border-gray-400'
          }`}
        >
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center">
                <Upload className="w-10 h-10 text-gray-400" />
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-base text-gray-900">
                Drag and drop your schedule here
              </p>
              <p className="text-sm text-gray-500">or</p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity text-sm"
              >
                Browse Files
              </button>
            </div>

            <p className="text-xs text-gray-500">
              Supports: JPG, PNG, PDF
            </p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/jpg,application/pdf"
            onChange={handleFileInputChange}
            className="hidden"
          />
        </div>

        {/* Selected File Preview */}
        {selectedFile && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-5">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center flex-shrink-0">
                {selectedFile.type === 'application/pdf' ? (
                  <FileText className="w-5 h-5 text-green-600" />
                ) : (
                  <FileImage className="w-5 h-5 text-green-600" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <p className="text-sm text-gray-900 font-medium">File Selected</p>
                </div>
                <p className="text-sm text-gray-600 truncate">{selectedFile.name}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {(selectedFile.size / 1024).toFixed(2)} KB
                </p>
              </div>
              <button
                onClick={() => setSelectedFile(null)}
                className="p-1 hover:bg-green-200 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        )}

        {/* Example Formats */}
        <div className="bg-gray-50 rounded-xl p-5">
          <p className="text-sm text-gray-700 mb-3">
            <span className="font-medium">Example Schedule Formats:</span>
          </p>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>Timetable with class names and times</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>Weekly schedule grid</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <div className="w-1.5 h-1.5 rounded-full bg-primary" />
              <span>School-issued schedule document</span>
            </div>
          </div>
        </div>

        {/* Process Button */}
        <button
          onClick={handleSubmit}
          disabled={!selectedFile}
          className="w-full py-4 bg-primary text-primary-foreground rounded-xl hover:opacity-90 transition-opacity shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Process Schedule
        </button>
      </div>
    </div>
  );
}
