import { useState } from 'react';
import { Upload, ArrowLeft } from 'lucide-react';

interface SignUpScreenProps {
  onSignUp: (name: string, email: string, program: string) => void;
  onBackToLogin: () => void;
}

export function SignUpScreen({ onSignUp, onBackToLogin }: SignUpScreenProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [program, setProgram] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email && program && password && password === confirmPassword) {
      onSignUp(name, email, program);
    }
  };

  return (
    <div className="flex flex-col min-h-screen p-6 bg-white">
      {/* Header */}
      <div className="flex items-center mb-8">
        <button 
          onClick={onBackToLogin}
          className="p-2 -ml-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full">
        {/* Logo and Title */}
        <div className="text-center space-y-3 mb-8">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
              <Upload className="w-8 h-8 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-2xl text-gray-900">Create Account</h1>
          <p className="text-sm text-gray-500">Join us to organize your schedule</p>
        </div>

        {/* Sign Up Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="name" className="block text-sm text-gray-700">
              Full Name
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="Enter your full name"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="signup-email" className="block text-sm text-gray-700">
              Student Email / ID
            </label>
            <input
              id="signup-email"
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="Enter your email or student ID"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="program" className="block text-sm text-gray-700">
              Course / Program
            </label>
            <input
              id="program"
              type="text"
              value={program}
              onChange={(e) => setProgram(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="e.g., Computer Science"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="signup-password" className="block text-sm text-gray-700">
              Password
            </label>
            <input
              id="signup-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="Create a password"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="confirm-password" className="block text-sm text-gray-700">
              Confirm Password
            </label>
            <input
              id="confirm-password"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="Confirm your password"
              required
            />
          </div>

          {password && confirmPassword && password !== confirmPassword && (
            <p className="text-sm text-red-500">Passwords do not match</p>
          )}

          <button
            type="submit"
            disabled={!name || !email || !program || !password || password !== confirmPassword}
            className="w-full py-3 bg-primary text-primary-foreground rounded-xl hover:opacity-90 transition-opacity shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Create Account
          </button>
        </form>
      </div>
    </div>
  );
}
