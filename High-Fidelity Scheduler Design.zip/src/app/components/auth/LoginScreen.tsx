import { useState } from 'react';
import { Upload } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (email: string) => void;
  onSignUp: () => void;
}

export function LoginScreen({ onLogin, onSignUp }: LoginScreenProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      onLogin(email);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-white">
      <div className="w-full max-w-sm space-y-8">
        {/* Logo and Title */}
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
              <Upload className="w-8 h-8 text-primary-foreground" />
            </div>
          </div>
          <h1 className="text-2xl text-gray-900">Student Automatic Scheduler</h1>
          <p className="text-sm text-gray-500">"Upload once. Organized instantly."</p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label htmlFor="email" className="block text-sm text-gray-700">
              Email / Student ID
            </label>
            <input
              id="email"
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="Enter your email or student ID"
              required
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm text-gray-700">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition"
              placeholder="Enter your password"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-primary text-primary-foreground rounded-xl hover:opacity-90 transition-opacity shadow-sm"
          >
            Log In
          </button>
        </form>

        {/* Sign Up Link */}
        <div className="text-center">
          <button
            onClick={onSignUp}
            className="text-sm text-gray-600 hover:text-primary transition-colors"
          >
            Don't have an account? <span className="underline">Sign Up</span>
          </button>
        </div>
      </div>
    </div>
  );
}
