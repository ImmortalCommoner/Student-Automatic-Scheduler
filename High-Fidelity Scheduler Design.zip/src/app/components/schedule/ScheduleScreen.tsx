import { useState } from 'react';
import { ArrowLeft, Clock, MapPin, Video, Users } from 'lucide-react';
import type { ScheduleData, ClassItem } from '@/app/App';

interface ScheduleScreenProps {
  scheduleData: ScheduleData;
  onBack: () => void;
  viewMode: 'week' | 'day';
  showUniform: boolean;
}

export function ScheduleScreen({ scheduleData, onBack, viewMode, showUniform }: ScheduleScreenProps) {
  const [selectedDay, setSelectedDay] = useState('Monday');
  const [selectedClass, setSelectedClass] = useState<ClassItem | null>(null);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const timeSlots = ['07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'];

  const getClassesForDay = (day: string) => {
    return scheduleData.classes.filter(c => c.day === day);
  };

  const getClassAtTime = (day: string, time: string) => {
    const dayClasses = getClassesForDay(day);
    return dayClasses.find(c => {
      const classHour = parseInt(c.startTime.split(':')[0]);
      const slotHour = parseInt(time.split(':')[0]);
      return classHour === slotHour;
    });
  };

  const getDayUniform = (day: string) => {
    const dayClasses = getClassesForDay(day);
    return dayClasses.find(c => c.uniform)?.uniform;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-gray-100 px-6 py-4">
        <div className="flex items-center gap-3 mb-3">
          <button 
            onClick={onBack}
            className="p-2 -ml-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-xl text-gray-900">My Schedule</h1>
        </div>

        {/* Day selector for day view */}
        {viewMode === 'day' && (
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-2 px-2">
            {days.map((day) => (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap transition-colors ${
                  selectedDay === day
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="p-6">
        {viewMode === 'week' ? (
          /* Week View */
          <div className="space-y-6">
            {days.map((day) => {
              const dayClasses = getClassesForDay(day);
              const uniform = getDayUniform(day);

              return (
                <div key={day} className="bg-gray-50 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-base text-gray-900">{day}</h3>
                    {showUniform && uniform && (
                      <span className="text-xs px-3 py-1 bg-blue-100 text-blue-700 rounded-full">
                        Uniform: {uniform}
                      </span>
                    )}
                  </div>

                  {dayClasses.length > 0 ? (
                    <div className="space-y-3">
                      {dayClasses.map((classItem) => (
                        <button
                          key={classItem.id}
                          onClick={() => setSelectedClass(classItem)}
                          className={`w-full text-left p-4 rounded-xl border transition-all hover:shadow-md ${
                            classItem.type === 'face-to-face'
                              ? 'bg-blue-50 border-blue-200 hover:bg-blue-100'
                              : 'bg-red-50 border-red-200 hover:bg-red-100'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <p className="text-sm text-gray-900 font-medium">{classItem.subjectName}</p>
                              <p className="text-xs text-gray-600 mt-0.5">{classItem.subjectCode}</p>
                            </div>
                            <div className={`px-2 py-1 rounded-lg text-xs ${
                              classItem.type === 'face-to-face'
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-red-100 text-red-700'
                            }`}>
                              {classItem.type === 'face-to-face' ? (
                                <span className="flex items-center gap-1">
                                  <Users className="w-3 h-3" />
                                  F2F
                                </span>
                              ) : (
                                <span className="flex items-center gap-1">
                                  <Video className="w-3 h-3" />
                                  Virtual
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 text-xs text-gray-600">
                            <Clock className="w-3 h-3" />
                            <span>{classItem.startTime} - {classItem.endTime}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 text-center py-6">No classes</p>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          /* Day View */
          <div className="space-y-4">
            {showUniform && getDayUniform(selectedDay) && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <p className="text-sm text-gray-700">
                  Uniform for {selectedDay}: <span className="font-medium">{getDayUniform(selectedDay)}</span>
                </p>
              </div>
            )}

            <div className="space-y-2">
              {timeSlots.map((time) => {
                const classItem = getClassAtTime(selectedDay, time);
                
                return (
                  <div key={time} className="flex gap-3">
                    <div className="w-16 flex-shrink-0 pt-2">
                      <p className="text-xs text-gray-500">{time}</p>
                    </div>
                    {classItem ? (
                      <button
                        onClick={() => setSelectedClass(classItem)}
                        className={`flex-1 p-4 rounded-xl border text-left transition-all hover:shadow-md ${
                          classItem.type === 'face-to-face'
                            ? 'bg-blue-50 border-blue-200 hover:bg-blue-100'
                            : 'bg-red-50 border-red-200 hover:bg-red-100'
                        }`}
                      >
                        <p className="text-sm text-gray-900 font-medium mb-1">{classItem.subjectName}</p>
                        <p className="text-xs text-gray-600 mb-2">{classItem.subjectCode}</p>
                        <div className="flex items-center gap-3">
                          <span className="text-xs text-gray-600">{classItem.startTime} - {classItem.endTime}</span>
                          <span className={`px-2 py-0.5 rounded text-xs ${
                            classItem.type === 'face-to-face'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {classItem.type === 'face-to-face' ? 'F2F' : 'Virtual'}
                          </span>
                        </div>
                      </button>
                    ) : (
                      <div className="flex-1 p-4 border border-dashed border-gray-200 rounded-xl bg-gray-50/50">
                        <p className="text-xs text-gray-400">Free</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Class Details Modal */}
      {selectedClass && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-6"
          onClick={() => setSelectedClass(null)}
        >
          <div 
            className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <h3 className="text-lg text-gray-900 font-medium">{selectedClass.subjectName}</h3>
              <p className="text-sm text-gray-600">{selectedClass.subjectCode}</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Clock className="w-5 h-5 text-gray-600" />
                <div>
                  <p className="text-xs text-gray-600">Time</p>
                  <p className="text-sm text-gray-900">{selectedClass.startTime} - {selectedClass.endTime}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                {selectedClass.type === 'face-to-face' ? (
                  <MapPin className="w-5 h-5 text-gray-600" />
                ) : (
                  <Video className="w-5 h-5 text-gray-600" />
                )}
                <div>
                  <p className="text-xs text-gray-600">Type</p>
                  <p className="text-sm text-gray-900">
                    {selectedClass.type === 'face-to-face' ? 'Face-to-Face' : 'Virtual Class'}
                  </p>
                </div>
              </div>

              {selectedClass.uniform && (
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <Users className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-600">Uniform</p>
                    <p className="text-sm text-gray-900">{selectedClass.uniform}</p>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedClass(null)}
              className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
