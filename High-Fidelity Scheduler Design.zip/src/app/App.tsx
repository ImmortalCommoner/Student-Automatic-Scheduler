import { useState } from "react";
import { LoginScreen } from "@/app/components/auth/LoginScreen";
import { SignUpScreen } from "@/app/components/auth/SignUpScreen";
import { HomeScreen } from "@/app/components/home/HomeScreen";
import { UploadScreen } from "@/app/components/upload/UploadScreen";
import { ProcessingScreen } from "@/app/components/upload/ProcessingScreen";
import { ScheduleScreen } from "@/app/components/schedule/ScheduleScreen";
import { CustomizeScreen } from "@/app/components/settings/CustomizeScreen";

export type Screen =
  | "login"
  | "signup"
  | "home"
  | "upload"
  | "processing"
  | "schedule"
  | "customize";

export interface UserData {
  name: string;
  email: string;
  program: string;
}

export interface ScheduleData {
  classes: ClassItem[];
}

export interface ClassItem {
  id: string;
  subjectName: string;
  subjectCode: string;
  day: string;
  startTime: string;
  endTime: string;
  type: "face-to-face" | "virtual";
  uniform?: string;
}

export default function App() {
  const [currentScreen, setCurrentScreen] =
    useState<Screen>("login");
  const [userData, setUserData] = useState<UserData | null>(
    null,
  );
  const [scheduleData, setScheduleData] =
    useState<ScheduleData | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [viewMode, setViewMode] = useState<"week" | "day">(
    "week",
  );
  const [showUniform, setShowUniform] = useState(true);
  const [fontSize, setFontSize] = useState<
    "small" | "medium" | "large"
  >("medium");

  const handleLogin = (email: string) => {
    // Mock login - in real app would authenticate
    setUserData({
      name: email.split("@")[0],
      email,
      program: "Computer Science",
    });
    setCurrentScreen("home");
  };

  const handleSignUp = (
    name: string,
    email: string,
    program: string,
  ) => {
    setUserData({ name, email, program });
    setCurrentScreen("home");
  };

  const handleLogout = () => {
    setUserData(null);
    setScheduleData(null);
    setCurrentScreen("login");
  };

  const handleUploadComplete = (file: File) => {
    setCurrentScreen("processing");
    // Simulate processing delay
    setTimeout(() => {
      // Mock schedule data
      const mockSchedule: ScheduleData = {
        classes: [
          {
            id: "1",
            subjectName: "Data Structures",
            subjectCode: "CS 301",
            day: "Monday",
            startTime: "09:00",
            endTime: "10:30",
            type: "face-to-face",
            uniform: "Traditional",
          },
          {
            id: "2",
            subjectName: "Database Systems",
            subjectCode: "CS 302",
            day: "Monday",
            startTime: "11:00",
            endTime: "12:30",
            type: "virtual",
          },
          {
            id: "3",
            subjectName: "Algorithms",
            subjectCode: "CS 303",
            day: "Tuesday",
            startTime: "10:00",
            endTime: "11:30",
            type: "face-to-face",
            uniform: "Traditonal",
          },
          {
            id: "4",
            subjectName: "Web Development",
            subjectCode: "CS 304",
            day: "Wednesday",
            startTime: "13:00",
            endTime: "14:30",
            type: "face-to-face",
            uniform: "Any",
          },
          {
            id: "5",
            subjectName: "Software Engineering",
            subjectCode: "CS 305",
            day: "Thursday",
            startTime: "09:00",
            endTime: "10:30",
            type: "virtual",
          },
          {
            id: "6",
            subjectName: "Mobile Development",
            subjectCode: "CS 306",
            day: "Friday",
            startTime: "14:00",
            endTime: "15:30",
            type: "face-to-face",
            uniform: "ESS",
          },
        ],
      };
      setScheduleData(mockSchedule);
      setCurrentScreen("schedule");
    }, 3000);
  };

  return (
    <div
      className={`min-h-screen ${isDarkMode ? "dark bg-gray-900" : "bg-gray-50"}`}
      style={{
        fontSize:
          fontSize === "small"
            ? "14px"
            : fontSize === "large"
              ? "18px"
              : "16px",
      }}
    >
      <div className="max-w-md mx-auto min-h-screen bg-background text-foreground">
        {currentScreen === "login" && (
          <LoginScreen
            onLogin={handleLogin}
            onSignUp={() => setCurrentScreen("signup")}
          />
        )}

        {currentScreen === "signup" && (
          <SignUpScreen
            onSignUp={handleSignUp}
            onBackToLogin={() => setCurrentScreen("login")}
          />
        )}

        {currentScreen === "home" && userData && (
          <HomeScreen
            userData={userData}
            scheduleData={scheduleData}
            onUpload={() => setCurrentScreen("upload")}
            onViewSchedule={() => setCurrentScreen("schedule")}
            onSettings={() => setCurrentScreen("customize")}
            onLogout={handleLogout}
            showUniform={showUniform}
          />
        )}

        {currentScreen === "upload" && (
          <UploadScreen
            onUpload={handleUploadComplete}
            onBack={() => setCurrentScreen("home")}
          />
        )}

        {currentScreen === "processing" && <ProcessingScreen />}

        {currentScreen === "schedule" && scheduleData && (
          <ScheduleScreen
            scheduleData={scheduleData}
            onBack={() => setCurrentScreen("home")}
            viewMode={viewMode}
            showUniform={showUniform}
          />
        )}

        {currentScreen === "customize" && (
          <CustomizeScreen
            isDarkMode={isDarkMode}
            viewMode={viewMode}
            showUniform={showUniform}
            fontSize={fontSize}
            onDarkModeToggle={() => setIsDarkMode(!isDarkMode)}
            onViewModeChange={(mode) => setViewMode(mode)}
            onShowUniformToggle={() =>
              setShowUniform(!showUniform)
            }
            onFontSizeChange={(size) => setFontSize(size)}
            onBack={() => setCurrentScreen("home")}
          />
        )}
      </div>
    </div>
  );
}