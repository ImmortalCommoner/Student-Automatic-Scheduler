
  # High-Fidelity Scheduler Design

  This is a code bundle for High-Fidelity Scheduler Design. The original project is available at https://www.figma.com/design/CoZds80P7xoWRZOJT1hLtL/High-Fidelity-Scheduler-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  